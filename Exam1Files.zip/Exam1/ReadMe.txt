Numerical simulations Exam 1 Report
